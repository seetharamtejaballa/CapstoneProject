package com.infy.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.infy.dto.TrainDTO;

@Entity
public class Train {
	@Id
	int id;
	String trainName;
	String arrivalTime;
	String deprtureTime;
	double fare;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public String getDeprtureTime() {
		return deprtureTime;
	}
	public void setDeprtureTime(String deprtureTime) {
		this.deprtureTime = deprtureTime;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	
	
	public static TrainDTO prepareTrainDTO(Train train)
	{
		TrainDTO  trainDTO = new TrainDTO();
		trainDTO.setId(train.getId());
		trainDTO.setTrainName(train.getTrainName());
		trainDTO.setArrivalTime(train.getArrivalTime());
		trainDTO.setDeprtureTime(train.getDeprtureTime());
		trainDTO.setFare(train.getFare());
		
		return trainDTO;
	}
	

}
