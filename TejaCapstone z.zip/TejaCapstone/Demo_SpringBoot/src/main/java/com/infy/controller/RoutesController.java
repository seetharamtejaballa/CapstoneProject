package com.infy.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.infy.dto.RouteDTO;
import com.infy.dto.TrainDTO;

import com.infy.service.RailService;

@RequestMapping("/routes")
@RestController 
@Validated
public class RoutesController {
	@Autowired
	RailService railService;
	
	@PostMapping
	public ResponseEntity<Integer> CreateRoute(@Valid @RequestBody RouteDTO routeDTO) {
		
		return ResponseEntity.ok(railService.CreateRoute(routeDTO));
		
	}
		
	@GetMapping(value="/{rId}")
	public ResponseEntity<RouteDTO> GetRouteById(@PathVariable("rId") @Min(100) @Max(999) int rId){
		
		return ResponseEntity.ok(railService.GetRouteById(rId));		
	}


	@GetMapping("/trains")
	public ResponseEntity<List<TrainDTO>> GetTrains(@RequestParam("source")@Pattern(regexp="^[A-Za-z]*$",message = "{route.source.invalid}") String source, @RequestParam("destination") @Pattern(regexp="^[A-Za-z]*$",message = "{route.destination.invalid}")String  destination){
		System.out.println("GetTrains");
		return ResponseEntity.ok(railService.GetTrains(source,destination));
		
	}
	

	@PutMapping(value="/update/{rId}")
    public ResponseEntity<String> PutRouteById(@PathVariable("rId") int rId,@MatrixVariable  Map<String, String> map ){
		
		return ResponseEntity.ok(railService.UpdateRoute(rId, map.get("source"), map.get("destination")));
					
	}

	@DeleteMapping(value="/{routeId}/{trainId}")
	public ResponseEntity<String> RemoveTrains(@PathVariable("routeId") int routeId,@PathVariable("trainId") int trainId) {
		String s=railService.RemoveTrains(routeId,trainId);
			
		return ResponseEntity.ok(s);	
	}
	
	@PutMapping(value="/{routeId}")
    public ResponseEntity<String> PutRouteById(@PathVariable("routeId") int routeId, @RequestBody TrainDTO trainDTO ){
		
		String s= railService.UpdateTrain(routeId, trainDTO);
		return ResponseEntity.ok(s);
	}
		
}

