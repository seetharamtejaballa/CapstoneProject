package com.infy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.Entity.Route;
import com.infy.Entity.Train;
import com.infy.dto.RouteDTO;
import com.infy.dto.TrainDTO;
import com.infy.repository.RouteRepository;
import com.infy.repository.TrainRepository;


@Service
public class RailService {
	private static int count=100;
	@Autowired
	RouteRepository routeRepository;
	
	@Autowired
	TrainRepository trainRepository;
	

	public int CreateRoute(RouteDTO routeDTO) {
		// TODO Auto-generated method stub
		Route r=new Route();
		r.setId(++RailService.count);
		r.setSource(routeDTO.getSource());
		r.setDestination(routeDTO.getDestination());
		r.setTrainList(Route.setTrainsByTrainDTOList(routeDTO.getTrainList()));
		routeRepository.save(r);
		
		return r.getId();
	}


	public RouteDTO GetRouteById(int routeId) {
		// TODO Auto-generated method stub
		RouteDTO rDTO=new RouteDTO();
		Optional<Route>  rOpt=routeRepository.findById(routeId);
		if(rOpt.isEmpty()) {
		 System.out.println("No Route is Found with the Given routeId:"+routeId);
			 return rDTO;
			}
		Route r=rOpt.get();
		
		rDTO.setId(r.getId());
		rDTO.setDestination(r.getDestination());
		rDTO.setSource(r.getSource());
		rDTO.setTrainList(RouteDTO.setTrainsByTrainDTOList(r.getTrainList()));
		
		return rDTO;
	}

	
	
	public List<TrainDTO> GetTrains(String source, String destination) {
		
		Optional<Route> r=routeRepository.findBySourceAndDestination(source,destination);
		List<Train> tList=r.get().getTrainList();
		List<TrainDTO> tDList=new ArrayList<>();
		for(Train t:tList) {
			tDList.add(Train.prepareTrainDTO(t)); 
		}
			
		return tDList;
	}

	
	public String UpdateRoute(int routeId, String source, String destination) {
		// TODO Auto-generated method stub
		Optional<Route>  r=routeRepository.findById(routeId);
		if(r.isEmpty()) {
			return "No Route is Found with the Given routeId:"+routeId;	
			}
		
		r.get().setSource(source);
		r.get().setDestination(destination);
		routeRepository.save(r.get());
		return "The source and destination of Route given routeId:"+routeId+",is Updated Successfully";
	}



	public String RemoveTrains(int routeId, int trainId) {
		// TODO Auto-generated method stub
		Optional<Train>  t=trainRepository.findById(trainId);
		Train train;
		if(t.isEmpty()) {
			return "No Train is Found with the Given trainId:"+trainId;	
			}
		Optional<Route>  r=routeRepository.findById(routeId);
		if(r.isEmpty()) {
			return "No Route is Found with the Given routeId:"+routeId;	
			}
		
		List<Train> tList=r.get().getTrainList();
		boolean found=false;
		int i=0;
		for(int j=0;j<tList.size();j++) {
			if(tList.get(j).getId()==trainId) {
				i=j;
				found=true;
			}
		}
		if(found==false) {
			return "No Train is Found with the Given trainId:"+trainId +",in TainList of routeId"+routeId;
		}
		else {
		tList.remove(i);
		r.get().setTrainList(tList);
		routeRepository.save(r.get());		
		return "Train with the Given trainId:"+trainId +"is Deleted from TainList of routeId"+routeId;
		}
		
		
	}

	
	public String UpdateTrain(int routeId, TrainDTO trainDTO) {
		// TODO Auto-generated method stub
		Optional<Train>  t=trainRepository.findById(trainDTO.getId());
		Train train;
		if(t.isEmpty()) {
		train=TrainDTO.prepareTrainEntity(trainDTO);
		trainRepository.save(train);		
		}
		else {
			train=t.get();
		}
		Optional<Route> r=routeRepository.findById(routeId);
		if(r.isEmpty()) {
			return "No Route is Found with the Given routeId:"+routeId;	
			}
		List<Train> tList=r.get().getTrainList();
		tList.add(train);
		r.get().setTrainList(tList);
		routeRepository.save(r.get());
		return "Train List is updated Successfully for RouteId:"+routeId;
	}
	

	public int CreateTrain(@Valid TrainDTO trainDTO) {
		// TODO Auto-generated method stub
		Train t=TrainDTO.prepareTrainEntity(trainDTO);
		trainRepository.save(t);
		return t.getId();
	}


	public String UpdateTrainFare(int trainId, double fare) {
		// TODO Auto-generated method stub
		Optional<Train>  t=trainRepository.findById(trainId);
		if(t.isEmpty()) {
			return "No train is found with the given TrainId";
		}
		t.get().setFare(fare);
		trainRepository.save(t.get());
		return "Train fare is update Successfully with:"+fare;
	}


	
}
